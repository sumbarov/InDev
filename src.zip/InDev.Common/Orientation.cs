﻿namespace InDev.Common
{
    public enum Orientation
    {
        None = 0,
        Left = 1,
        Top = 2,
        Right = 3,
        Bottom = 4
    }
}
